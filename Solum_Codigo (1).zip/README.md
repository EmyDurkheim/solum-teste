# Solum

Gestão financeira para MEIs com renda irregular: salário sintético, reserva do DAS, teto anual, clientes e faturas, precificação, metas e investimentos (Premium).

Sua liberdade merece estabilidade.

## Pastas

| Pasta | O que é |
| --- | --- |
| `solum-backend` | API em Python (FastAPI), regras de negócio em POO, PostgreSQL, testes e script do banco |
| `solum-web` | Painel web do administrador (React) |
| `solum-mobile` | App do MEI (React Native com Expo) |

## Ordem para rodar

1. **Backend**: siga `solum-backend/README.md` (instalar, configurar o `.env`, subir a API e rodar o seed de demonstração).
2. **Painel web**: siga `solum-web/README.md` e entre com `admin@solum.app`.
3. **App mobile**: siga `solum-mobile/README.md` e entre com `emilly@email.com`.

Cada pasta tem seu próprio README com os comandos para Windows.

## Documentos para o professor

Os PDFs (proposta, modelo de banco, diagramas e guia de telas) são entregues junto com este código.
